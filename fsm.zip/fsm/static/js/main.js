$(document).ready(function() {
    // --- Search Suggestions ---
    $('#searchInput').keyup(function(){
        var query = $(this).val();
        if(query.length > 2){
            $.getJSON("/youtube_suggestions", { q: query }, function(data){
                var suggestions = '';
                $.each(data, function(i, suggestion){
                    suggestions += '<li>' + suggestion + '</li>';
                });
                $('#suggestions').html(suggestions).show();
            });
        } else {
            $('#suggestions').hide();
        }
    });
    
    // Fill search box on suggestion click
    $(document).on('click', '#suggestions li', function(){
        $('#searchInput').val($(this).text());
        $('#suggestions').hide();
    });
    
    // --- Chat Functionality ---
    function fetchMessages() {
        $.getJSON("/get_messages", function(data){
            $("#chatBox").empty();
            $.each(data, function(i, msg){
                $("#chatBox").append("<p><strong>" + msg.sender + ":</strong> " + msg.message + " <small>(" + msg.timestamp + ")</small></p>");
            });
        });
    }
    
    // Update chat every 5 seconds
    setInterval(fetchMessages, 5000);
    
    // Global variable for current chat recipient
    window.currentReceiverId = null;
    
    window.openChat = function(receiverId, receiverName) {
        window.currentReceiverId = receiverId;
        $("#chatWith").text("Chatting with " + receiverName);
        $("#chatBox").empty();
        fetchMessages();
    };
    
    window.sendMessage = function() {
        var message = $("#chatMessage").val();
        if(message.trim() === "" || window.currentReceiverId == null) return;
        $.post("/send_message", { receiver_id: window.currentReceiverId, message: message }, function(response){
            $("#chatMessage").val("");
            fetchMessages();
        });
    };
});
