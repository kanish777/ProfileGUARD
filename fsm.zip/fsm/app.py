import os
import re
import json
import random
import requests
from datetime import datetime, timedelta
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from dotenv import load_dotenv
from twilio.rest import Client
from flask_mail import Mail, Message
from werkzeug.utils import secure_filename

load_dotenv()  # Load environment variables from .env

app = Flask(__name__)
app.secret_key = os.urandom(24)

# Configure SQLite database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///fsm.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Configure Uploads
app.config['UPLOAD_FOLDER'] = os.path.join('static', 'images')
app.config['PROFILE_UPLOAD_FOLDER'] = os.path.join(app.config['UPLOAD_FOLDER'], 'profiles')
app.config['POSTS_UPLOAD_FOLDER'] = os.path.join(app.config['UPLOAD_FOLDER'], 'posts')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

db = SQLAlchemy(app)

# Configure Flask-Mail
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = os.getenv('MAIL_USERNAME')
app.config['MAIL_PASSWORD'] = os.getenv('MAIL_PASSWORD')
app.config['MAIL_DEFAULT_SENDER'] = os.getenv('MAIL_USERNAME')
mail = Mail(app)

# Twilio configuration
TWILIO_ACCOUNT_SID = os.getenv('TWILIO_ACCOUNT_SID')
TWILIO_AUTH_TOKEN = os.getenv('TWILIO_AUTH_TOKEN')
TWILIO_VERIFY_SERVICE_SID = os.getenv('TWILIO_VERIFY_SERVICE_SID')
twilio_client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)

# YouTube API Key
YOUTUBE_API_KEY = os.getenv('YOUTUBE_API_KEY')

# ------------------
# Helper Functions
# ------------------
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def valid_password(password):
    """Ensure password is at least 8 characters with 1 uppercase, 1 symbol, and 1 number."""
    if len(password) < 8:
        return False
    if not re.search(r'[A-Z]', password):
        return False
    if not re.search(r'[0-9]', password):
        return False
    if not re.search(r'[\W_]', password):
        return False
    return True

def analyze_text_risk(text):
    """
    Analyze input text using the offensive words JSON.
    Returns the cumulative risk increment.
    """
    risk_increment = 0
    try:
        with open('offensive_words.json', 'r') as f:
            offensive_data = json.load(f)
        for word, severity in offensive_data.items():
            if word.lower() in text.lower():
                risk_increment += severity
    except Exception as e:
        pass
    return risk_increment

def check_offensive_in_inputs(form_data):
    """
    Check all form inputs for offensive language and sum the risk.
    """
    total_risk = 0
    for key, value in form_data.items():
        if isinstance(value, str):
            total_risk += analyze_text_risk(value)
    return total_risk

def detect_fake_thumbnail(url):
    """
    Stub for fake thumbnail detection using a CNN/CV approach.
    In production, load your CNN model and perform image analysis.
    Here, we simulate detection with a 10% chance of flagging the thumbnail as fake/sensitive.
    """
    return random.random() < 0.1

def check_risk_and_suspend(user):
    """
    Suspend or ban the user based on overall risk score.
      - 1st violation (>=100): suspend for 3 hours
      - 2nd violation (>=200): suspend for 1 day
      - 3rd violation (>=300): suspend for 1 week
      - 4th violation (>=400): ban and delete account
    """
    if user.overall_risk_score >= 100 and user.violation_count == 0:
        user.violation_count = 1
        user.suspended_until = datetime.utcnow() + timedelta(hours=3)
        db.session.commit()
        flash('First violation detected: Account suspended for 3 hours.', 'danger')
        session.pop('user', None)
        return redirect(url_for('index'))
    elif user.overall_risk_score >= 200 and user.violation_count == 1:
        user.violation_count = 2
        user.suspended_until = datetime.utcnow() + timedelta(days=1)
        db.session.commit()
        flash('Second violation: Account suspended for 1 day.', 'danger')
        session.pop('user', None)
        return redirect(url_for('index'))
    elif user.overall_risk_score >= 300 and user.violation_count == 2:
        user.violation_count = 3
        user.suspended_until = datetime.utcnow() + timedelta(weeks=1)
        db.session.commit()
        flash('Third violation: Account suspended for 1 week.', 'danger')
        session.pop('user', None)
        return redirect(url_for('index'))
    elif user.overall_risk_score >= 400 and user.violation_count >= 3:
        flash('Fourth violation: You are banned and your account will be deleted.', 'danger')
        db.session.delete(user)
        db.session.commit()
        session.pop('user', None)
        return redirect(url_for('banned'))
    return None

# ------------------
# Models
# ------------------
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    first_name  = db.Column(db.String(100))
    last_name   = db.Column(db.String(100))
    age         = db.Column(db.Integer)
    gender      = db.Column(db.String(20))
    email       = db.Column(db.String(120), unique=True, nullable=False)
    password    = db.Column(db.String(200), nullable=False)
    phone       = db.Column(db.String(20))
    address1    = db.Column(db.String(200))
    address2    = db.Column(db.String(200))
    aadhar      = db.Column(db.String(50))
    profile_photo = db.Column(db.String(300), nullable=True)
    is_verified = db.Column(db.Boolean, default=False)
    overall_risk_score = db.Column(db.Integer, default=0)
    violation_count = db.Column(db.Integer, default=0)
    suspended_until = db.Column(db.DateTime, nullable=True)
    banned = db.Column(db.Boolean, default=False)
    posts = db.relationship('Post', backref='author', lazy=True)
    comments = db.relationship('Comment', backref='commenter', lazy=True)
    chats_sent = db.relationship('Chat', foreign_keys='Chat.sender_id', backref='sender', lazy=True)
    chats_received = db.relationship('Chat', foreign_keys='Chat.receiver_id', backref='receiver', lazy=True)

class Post(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text)
    media_file = db.Column(db.String(300), nullable=True)
    risk_score = db.Column(db.Integer, default=0)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    comments = db.relationship('Comment', backref='post', lazy=True)

class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text)
    risk_score = db.Column(db.Integer, default=0)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    post_id = db.Column(db.Integer, db.ForeignKey('post.id'), nullable=True)
    video_id = db.Column(db.String(50), nullable=True)
    parent_id = db.Column(db.Integer, db.ForeignKey('comment.id'), nullable=True)
    replies = db.relationship('Comment', backref=db.backref('parent', remote_side=[id]), lazy=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))

class Chat(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    receiver_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    message = db.Column(db.Text)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    risk_score = db.Column(db.Integer, default=0)

# ------------------
# Routes
# ------------------
@app.route('/')
def index():
    queries = ["music", "news", "sports", "comedy", "technology"]
    query = random.choice(queries)
    pageToken = request.args.get('pageToken', '')
    api_url = "https://www.googleapis.com/youtube/v3/search"
    params = {
        'part': 'snippet',
        'q': query,
        'key': YOUTUBE_API_KEY,
        'type': 'video',
        'maxResults': 48
    }
    if pageToken:
        params['pageToken'] = pageToken
    response = requests.get(api_url, params=params)
    videos = []
    nextPageToken = ""
    prevPageToken = ""
    if response.status_code == 200:
        data = response.json()
        nextPageToken = data.get('nextPageToken', '')
        prevPageToken = data.get('prevPageToken', '')
        for item in data.get('items', []):
            thumbnail = item['snippet']['thumbnails']['medium']['url']
            # Use CV/CNN stub to check if thumbnail is fake
            if detect_fake_thumbnail(thumbnail):
                continue  # Skip video if thumbnail is flagged as fake/sensitive
            video = {
                'title': item['snippet']['title'],
                'thumbnail': thumbnail,
                'videoId': item['id']['videoId'],
                'risk': random.randint(0, 100)  # For demo, assign a random risk score
            }
            videos.append(video)
    else:
        flash('Error fetching YouTube videos.', 'danger')
    return render_template('index.html', videos=videos, nextPageToken=nextPageToken, prevPageToken=prevPageToken)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        form_risk = check_offensive_in_inputs(request.form)
        first_name = request.form.get('first_name')
        last_name  = request.form.get('last_name')
        age        = request.form.get('age')
        gender     = request.form.get('gender')
        email      = request.form.get('email')
        password   = request.form.get('password')
        phone      = request.form.get('phone')
        address1   = request.form.get('address1')
        address2   = request.form.get('address2')
        aadhar     = request.form.get('aadhar')
        if not valid_password(password):
            flash('Password must be at least 8 characters with 1 uppercase, 1 symbol, and 1 number.', 'danger')
            return redirect(url_for('register'))
        if User.query.filter_by(email=email).first():
            flash('User already exists. Please log in.', 'danger')
            return redirect(url_for('login'))
        # Handle profile photo upload
        profile_photo = None
        if 'profile_photo' in request.files:
            file = request.files['profile_photo']
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                filepath = os.path.join(app.config['PROFILE_UPLOAD_FOLDER'], filename)
                file.save(filepath)
                profile_photo = filepath
        session['pending_user'] = {
            'first_name': first_name, 'last_name': last_name, 'age': age,
            'gender': gender, 'email': email, 'password': password,
            'phone': phone, 'address1': address1, 'address2': address2, 'aadhar': aadhar,
            'profile_photo': profile_photo,
            'form_risk': form_risk
        }
        try:
            twilio_client.verify.services(TWILIO_VERIFY_SERVICE_SID).verifications.create(
                to=phone, channel='sms'
            )
            flash('OTP sent to your phone. Please verify.', 'info')
            return redirect(url_for('verify'))
        except Exception as e:
            flash('Failed to send OTP: ' + str(e), 'danger')
            return redirect(url_for('register'))
    return render_template('register.html')

@app.route('/verify', methods=['GET', 'POST'])
def verify():
    if request.method == 'POST':
        otp = request.form.get('otp')
        phone = session.get('pending_user', {}).get('phone')
        if not phone:
            flash('No pending registration found.', 'danger')
            return redirect(url_for('register'))
        try:
            verification_check = twilio_client.verify.services(TWILIO_VERIFY_SERVICE_SID).verification_checks.create(
                to=phone, code=otp
            )
            if verification_check.status == 'approved':
                pending = session.pop('pending_user', None)
                if pending:
                    new_user = User(
                        first_name=pending.get('first_name'),
                        last_name=pending.get('last_name'),
                        age=int(pending.get('age')) if pending.get('age') else None,
                        gender=pending.get('gender'),
                        email=pending.get('email'),
                        password=pending.get('password'),
                        phone=pending.get('phone'),
                        address1=pending.get('address1'),
                        address2=pending.get('address2'),
                        aadhar=pending.get('aadhar'),
                        profile_photo=pending.get('profile_photo'),
                        overall_risk_score=pending.get('form_risk', 0),
                        is_verified=True
                    )
                    db.session.add(new_user)
                    db.session.commit()
                    flash('Registration successful and OTP verified!', 'success')
                    session['user'] = new_user.email
                    return redirect(url_for('index'))
                else:
                    flash('Pending registration data not found.', 'danger')
                    return redirect(url_for('register'))
            else:
                flash('Invalid OTP. Please try again.', 'danger')
        except Exception as e:
            flash('OTP verification failed: ' + str(e), 'danger')
    return render_template('verify.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        form_risk = check_offensive_in_inputs(request.form)
        email = request.form.get('email')
        password = request.form.get('password')
        user = User.query.filter_by(email=email, password=password, is_verified=True).first()
        if user:
            if user.suspended_until and user.suspended_until > datetime.utcnow():
                flash('Your account is suspended until ' + user.suspended_until.strftime("%Y-%m-%d %H:%M:%S"), 'danger')
                return redirect(url_for('login'))
            if user.banned:
                flash('Your account is banned permanently.', 'danger')
                return redirect(url_for('banned'))
            try:
                twilio_client.verify.services(TWILIO_VERIFY_SERVICE_SID).verifications.create(
                    to=user.phone, channel='sms'
                )
                session['pending_login'] = user.email
                flash('OTP sent to your phone for login verification.', 'info')
                return redirect(url_for('verify_login'))
            except Exception as e:
                flash('Failed to send OTP: ' + str(e), 'danger')
                return redirect(url_for('login'))
        else:
            flash('Invalid credentials or unverified account.', 'danger')
            return redirect(url_for('login'))
    return render_template('login.html')

@app.route('/verify_login', methods=['GET', 'POST'])
def verify_login():
    if request.method == 'POST':
        otp = request.form.get('otp')
        pending_email = session.get('pending_login')
        if not pending_email:
            flash('No pending login found.', 'danger')
            return redirect(url_for('login'))
        user = User.query.filter_by(email=pending_email).first()
        if not user:
            flash('User not found.', 'danger')
            return redirect(url_for('login'))
        try:
            verification_check = twilio_client.verify.services(TWILIO_VERIFY_SERVICE_SID).verification_checks.create(
                to=user.phone, code=otp
            )
            if verification_check.status == 'approved':
                session.pop('pending_login', None)
                session['user'] = user.email
                flash('Login successful!', 'success')
                return redirect(url_for('index'))
            else:
                flash('Invalid OTP. Please try again.', 'danger')
        except Exception as e:
            flash('OTP verification failed: ' + str(e), 'danger')
    return render_template('verify.html', is_login=True)

@app.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form.get('email')
        user = User.query.filter_by(email=email).first()
        if user:
            try:
                msg = Message('Your Password', sender=app.config['MAIL_DEFAULT_SENDER'], recipients=[email])
                msg.body = f"Your password is: {user.password}"
                mail.send(msg)
                flash('Password sent to your email.', 'success')
            except Exception as e:
                flash('Failed to send email: ' + str(e), 'danger')
        else:
            flash('Email not found.', 'danger')
    return render_template('forgot_password.html')

@app.route('/account', methods=['GET', 'POST'])
def account():
    if 'user' not in session:
        flash('Please log in first.', 'danger')
        return redirect(url_for('login'))
    email = session['user']
    user = User.query.filter_by(email=email).first()
    if request.method == 'POST':
        form_risk = check_offensive_in_inputs(request.form)
        user.first_name = request.form.get('first_name')
        user.last_name  = request.form.get('last_name')
        user.age        = int(request.form.get('age')) if request.form.get('age') else None
        user.gender     = request.form.get('gender')
        user.phone      = request.form.get('phone')
        user.address1   = request.form.get('address1')
        user.address2   = request.form.get('address2')
        aadhar          = request.form.get('aadhar')
        if aadhar:
            user.aadhar = aadhar
        new_password = request.form.get('password')
        if new_password:
            if valid_password(new_password):
                user.password = new_password
            else:
                flash('New password does not meet criteria.', 'danger')
                return redirect(url_for('account'))
        # Handle profile photo update
        if 'profile_photo' in request.files:
            file = request.files['profile_photo']
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                filepath = os.path.join(app.config['PROFILE_UPLOAD_FOLDER'], filename)
                file.save(filepath)
                user.profile_photo = filepath
        user.overall_risk_score += form_risk
        db.session.commit()
        flash('Account updated successfully!', 'success')
        return redirect(url_for('account'))
    return render_template('account.html', user=user)

@app.route('/risk')
def risk():
    if 'user' not in session:
        flash('Please log in first.', 'danger')
        return redirect(url_for('login'))
    user = User.query.filter_by(email=session['user']).first()
    risk_score = user.overall_risk_score if user else 0
    return render_template('risk.html', risk_score=risk_score)

@app.route('/risk_data')
def risk_data():
    if 'user' not in session:
        return jsonify({'risk_score': 0})
    user = User.query.filter_by(email=session['user']).first()
    return jsonify({'risk_score': user.overall_risk_score})

@app.route('/activities')
def activities():
    if 'user' not in session:
        flash('Please log in first.', 'danger')
        return redirect(url_for('login'))
    user = User.query.filter_by(email=session['user']).first()
    login_count = session.get('login_count', 1)
    posts_count = Post.query.filter_by(user_id=user.id).count()
    comments_count = Comment.query.filter_by(user_id=user.id).count()
    activities_data = {'login_count': login_count, 'posts': posts_count, 'comments': comments_count}
    return render_template('activities.html', activities=activities_data)

@app.route('/activities_data')
def activities_data():
    if 'user' not in session:
        return jsonify({'login_count': 0, 'posts': 0, 'comments': 0})
    user = User.query.filter_by(email=session['user']).first()
    login_count = session.get('login_count', 1)
    posts_count = Post.query.filter_by(user_id=user.id).count()
    comments_count = Comment.query.filter_by(user_id=user.id).count()
    return jsonify({'login_count': login_count, 'posts': posts_count, 'comments': comments_count})

@app.route('/create_post', methods=['GET', 'POST'])
def create_post():
    if 'user' not in session:
        flash('Please log in to create a post.', 'danger')
        return redirect(url_for('login'))
    if request.method == 'POST':
        form_risk = check_offensive_in_inputs(request.form)
        content = request.form.get('content')
        media_file = None
        if 'media_file' in request.files:
            file = request.files['media_file']
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                filepath = os.path.join(app.config['POSTS_UPLOAD_FOLDER'], filename)
                file.save(filepath)
                media_file = filepath
        user = User.query.filter_by(email=session['user']).first()
        new_post = Post(content=content, media_file=media_file, user_id=user.id)
        new_post.risk_score = analyze_text_risk(content)
        db.session.add(new_post)
        user.overall_risk_score += analyze_text_risk(content) + form_risk
        db.session.commit()
        resp = check_risk_and_suspend(user)
        if resp:
            return resp
        flash('Post successfully created!', 'success')
        return redirect(url_for('posts'))
    return render_template('create_post.html')

@app.route('/posts')
def posts():
    page = request.args.get('page', 1, type=int)
    posts_paginated = Post.query.order_by(db.func.random()).paginate(page=page, per_page=48)
    return render_template('posts.html', posts=posts_paginated.items, pagination=posts_paginated)

@app.route('/post/<int:post_id>/comment', methods=['POST'])
def add_comment(post_id):
    if 'user' not in session:
        flash('Please log in to comment.', 'danger')
        return redirect(url_for('login'))
    comment_text = request.form.get('content')
    parent_id = request.form.get('parent_id')
    user = User.query.filter_by(email=session['user']).first()
    risk_incr = analyze_text_risk(comment_text)
    if risk_incr > 0:
        user.overall_risk_score += risk_incr
        db.session.commit()
        flash(f'Offensive comment detected. Risk score increased by {risk_incr} points.', 'danger')
        resp = check_risk_and_suspend(user)
        if resp:
            return resp
        return redirect(url_for('posts'))
    else:
        new_comment = Comment(content=comment_text, post_id=post_id, user_id=user.id)
        if parent_id:
            new_comment.parent_id = int(parent_id)
        new_comment.risk_score = risk_incr
        db.session.add(new_comment)
        db.session.commit()
        flash('Comment added successfully!', 'success')
        return redirect(url_for('posts'))


@app.route('/fetch_youtube')
def fetch_youtube():
    # Get filter parameters from the query string
    category = request.args.get('category', 'Videos')
    order = request.args.get('order', 'relevance')
    query = request.args.get('query', 'latest')
    
    api_url = "https://www.googleapis.com/youtube/v3/search"
    params = {
        'part': 'snippet',
        'q': query,
        'key': YOUTUBE_API_KEY,
        'type': 'video',
        'order': order,
        'maxResults': 10
    }
    # If category is "Shorts", set videoDuration to 'short'
    if category.lower() == 'shorts':
        params['videoDuration'] = 'short'
    # For "Posts" you might eventually return your own posts instead of YouTube videos.
    
    response = requests.get(api_url, params=params)
    results = []
    if response.status_code == 200:
        data = response.json()
        for item in data.get('items', []):
            thumbnail = item['snippet']['thumbnails']['medium']['url']
            if detect_fake_thumbnail(thumbnail):
                continue  # Skip if thumbnail flagged as fake/sensitive
            results.append({
                'title': item['snippet']['title'],
                'thumbnail': thumbnail,
                'videoId': item['id']['videoId']
            })
    return jsonify(results)

@app.route('/youtube/<video_id>/comment', methods=['POST'])
def youtube_comment(video_id):
    if 'user' not in session:
        flash('Please log in to comment.', 'danger')
        return redirect(url_for('login'))
    comment_text = request.form.get('content')
    user = User.query.filter_by(email=session['user']).first()
    risk_incr = analyze_text_risk(comment_text)
    if risk_incr > 0:
        user.overall_risk_score += risk_incr
        db.session.commit()
        flash(f'Offensive comment detected. Risk score increased by {risk_incr} points.', 'danger')
        resp = check_risk_and_suspend(user)
        if resp:
            return resp
        return redirect(url_for('index'))
    else:
        new_comment = Comment(content=comment_text, video_id=video_id, user_id=user.id)
        new_comment.risk_score = risk_incr
        db.session.add(new_comment)
        db.session.commit()
        flash('Comment added successfully!', 'success')
        return redirect(url_for('index'))

@app.route('/chat')
def chat():
    if 'user' not in session:
        flash('Please log in to access chat.', 'danger')
        return redirect(url_for('login'))
    # Generate random bot contacts with Indian names for demonstration
    bots = [
        {'id': 1001, 'name': 'Ram'},
        {'id': 1002, 'name': 'Suresh'},
        {'id': 1003, 'name': 'Geeta'},
        {'id': 1004, 'name': 'Amit'},
        {'id': 1005, 'name': 'Priya'},
        {'id': 1006, 'name': 'Vijay'},
        {'id': 1007, 'name': 'Sunita'},
        {'id': 1008, 'name': 'Ravi'},
        {'id': 1009, 'name': 'Anita'},
        {'id': 1010, 'name': 'Kiran'},
        {'id': 1011, 'name': 'Deepak'},
        {'id': 1012, 'name': 'Pooja'},
        {'id': 1013, 'name': 'Manoj'},
        {'id': 1014, 'name': 'Sonia'},
        {'id': 1015, 'name': 'Raj'}
    ]
    return render_template('chat.html', bots=bots)

@app.route('/send_message', methods=['POST'])
def send_message():
    if 'user' not in session:
        return jsonify({'status': 'error', 'message': 'Not logged in'})
    sender = User.query.filter_by(email=session['user']).first()
    receiver_id = request.form.get('receiver_id')
    message_text = request.form.get('message')
    risk_incr = analyze_text_risk(message_text)
    new_chat = Chat(sender_id=sender.id, receiver_id=receiver_id, message=message_text, risk_score=risk_incr)
    sender.overall_risk_score += risk_incr
    db.session.add(new_chat)
    db.session.commit()
    resp = check_risk_and_suspend(sender)
    if resp:
        return jsonify({'status': 'error', 'message': 'User suspended'})
    return jsonify({'status': 'success', 'message': 'Message sent'})

@app.route('/get_messages')
def get_messages():
    if 'user' not in session:
        return jsonify([])
    user = User.query.filter_by(email=session['user']).first()
    chats = Chat.query.filter((Chat.sender_id==user.id) | (Chat.receiver_id==user.id)).order_by(Chat.timestamp.asc()).all()
    messages = []
    for chat in chats:
        messages.append({
            'sender': chat.sender.first_name if chat.sender else 'Unknown',
            'receiver': chat.receiver.first_name if chat.receiver else 'Unknown',
            'message': chat.message,
            'timestamp': chat.timestamp.strftime("%Y-%m-%d %H:%M:%S")
        })
    return jsonify(messages)

@app.route('/switch_account')
def switch_account():
    session.pop('user', None)
    flash('Switched account. Please log in.', 'info')
    return redirect(url_for('login'))

@app.route('/logout')
def logout():
    session.pop('user', None)
    flash('Logged out successfully!', 'success')
    return redirect(url_for('index'))

@app.route('/banned')
def banned():
    return render_template('banned.html')

@app.route('/search')
def search():
    query = request.args.get('query')
    if not query:
        flash('No search query provided.', 'warning')
        return redirect(url_for('index'))
    api_url = "https://www.googleapis.com/youtube/v3/search"
    params = {
        'part': 'snippet',
        'q': query,
        'key': YOUTUBE_API_KEY,
        'type': 'video',
        'maxResults': 10
    }
    response = requests.get(api_url, params=params)
    results = []
    if response.status_code == 200:
        data = response.json()
        for item in data.get('items', []):
            thumbnail = item['snippet']['thumbnails']['medium']['url']
            if detect_fake_thumbnail(thumbnail):
                continue
            video = {
                'title': item['snippet']['title'],
                'thumbnail': thumbnail,
                'videoId': item['id']['videoId'],
                'risk': random.randint(0, 100)
            }
            results.append(video)
    else:
        flash('Error fetching search results.', 'danger')
    return render_template('search_results.html', query=query, results=results)

@app.route('/youtube_suggestions')
def youtube_suggestions():
    q = request.args.get('q', '')
    suggestions = []
    if q:
        api_url = "https://www.googleapis.com/youtube/v3/search"
        params = {
            'part': 'snippet',
            'q': q,
            'key': YOUTUBE_API_KEY,
            'type': 'video',
            'maxResults': 5
        }
        response = requests.get(api_url, params=params)
        if response.status_code == 200:
            data = response.json()
            suggestions = [item['snippet']['title'] for item in data.get('items', [])]
    return jsonify(suggestions)

@app.route('/apps')
def apps():
    apps_list = [
        {'name': 'YouTube', 'url': 'https://www.youtube.com', 'icon': 'fab fa-youtube'},
        {'name': 'Instagram', 'url': 'https://www.instagram.com', 'icon': 'fab fa-instagram'},
        {'name': 'TikTok', 'url': 'https://www.tiktok.com', 'icon': 'fab fa-tiktok'},
        {'name': 'Snapchat', 'url': 'https://www.snapchat.com', 'icon': 'fas fa-camera-retro'},
        {'name': 'Twitter', 'url': 'https://www.twitter.com', 'icon': 'fab fa-twitter'},
        {'name': 'Facebook', 'url': 'https://www.facebook.com', 'icon': 'fab fa-facebook'},
        {'name': 'LinkedIn', 'url': 'https://www.linkedin.com', 'icon': 'fab fa-linkedin'},
        {'name': 'Pinterest', 'url': 'https://www.pinterest.com', 'icon': 'fab fa-pinterest'},
        {'name': 'Reddit', 'url': 'https://www.reddit.com', 'icon': 'fab fa-reddit'}
    ]
    return render_template('apps.html', apps=apps_list)

@app.route('/about')
def about():
    return render_template('about.html')

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
